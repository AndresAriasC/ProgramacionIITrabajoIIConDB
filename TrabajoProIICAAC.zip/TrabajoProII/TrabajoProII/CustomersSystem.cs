﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrabajoProII
{
    public partial class CustomersSystem : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["Connection"].ConnectionString;


        public CustomersSystem()
        {
            InitializeComponent();
            GetCustomers();
        }

        private void GetCustomers() {
          //si se pudo 
            string queryString = "SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, PostalCode, Country, Phone, Fax FROM Customers";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);

                try
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgv1.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        //termina el metodo getcustomers Andres Arias

        private void dgv1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv1.Rows[e.RowIndex];
                campoCustomerId.Text = row.Cells["CustomerID"].Value.ToString();
                campoCompanyName.Text = row.Cells["CompanyName"].Value.ToString();
                campoContactName.Text = row.Cells["ContactName"].Value.ToString();
                campoContactTitle.Text = row.Cells["ContactTitle"].Value.ToString();
                campoAddress.Text = row.Cells["Address"].Value.ToString();
                campoPostCode.Text = row.Cells["PostalCode"].Value.ToString();
                campoCountry.Text = row.Cells["Country"].Value.ToString();
                campoPhone.Text = row.Cells["Phone"].Value.ToString();
                campoFax.Text = row.Cells["Fax"].Value.ToString();
            }
        }
        //termina el metodo dgv1cellclick

        private void btnCrear_Click(object sender, EventArgs e)
        {
            InsertCustomers();
        }
        //termina el metodo click de agregar Andres

        private void InsertCustomers() {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    //'" + campoCompanyName.Text+ "', " + campoContactName.Text + "', " + campoContactTitle.Text + "', " + campoAddress.Text + "', " + campoPostCode.Text + "', " + campoCountry.Text + "', " + campoPhone.Text + "', " +  campoFax.Text +"
                    string queryString = "INSERT INTO Customers(CustomerID, CompanyName, ContactName, ContactTitle, Address, PostalCode, Country, Phone, Fax) VALUES('" + campoCustomerId.Text + "','" + campoCompanyName.Text + "','" + campoContactName.Text + "','" + campoContactTitle.Text + "','" + campoAddress.Text + "','" + campoPostCode.Text + "','" + campoCountry.Text + "','" + campoPhone.Text + "','" + campoFax.Text +"')";
                    SqlCommand cmd = new SqlCommand(queryString, connection);
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cliente guardado correctamente");
                   GetCustomers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            campoCustomerId.Clear();
            campoCompanyName.Clear();
            campoContactName.Clear();
            campoContactTitle.Clear();
            campoCountry.Clear();
            campoAddress.Clear();
            campoPostCode.Clear();
            campoPhone.Clear();
            campoFax.Clear();
            campoCompanyName.Focus();
        }

        /*termina el metodo InsertCustomer Andres Arias*/
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                   
                    string queryString = "UPDATE Customers SET CompanyName = '" + campoCompanyName.Text
                      + "', ContactName = '" + campoContactName.Text + "', ContactTitle = '" + campoContactTitle.Text
                      + "', Address = '" + campoAddress.Text
                      + "', PostalCode = '" + campoPostCode.Text
                      + "', Country = '" + campoCountry.Text + "', Phone = '" + campoPhone.Text
                      + "', Fax = '" + campoFax.Text + "' WHERE CustomerID = '" + campoCustomerId.Text + "'";
                    SqlCommand cmd = new SqlCommand(queryString, connection);
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cliente actualizado correctamente");
                    GetCustomers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    string queryString = "DELETE FROM Customers WHERE CustomerID = '" + campoCustomerId.Text + "'";
                         SqlCommand cmd = new SqlCommand(queryString, connection);
                    connection.Open();
                        cmd.ExecuteNonQuery();
                    MessageBox.Show("Cliente eliminado correctamente");
                        GetCustomers();
                }
                catch (InvalidCastException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
